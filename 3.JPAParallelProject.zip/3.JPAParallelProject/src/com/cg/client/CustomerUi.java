package com.cg.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.entities.Account;
import com.cg.entities.Customer;
import com.cg.service.ServiceImpl;

public class CustomerUi {
	
	Scanner scanner = new Scanner(System.in);
	
	ServiceImpl service = new ServiceImpl();
	Customer customer = new Customer();
	Account account = new Account();
	
	static int id = 0, accountNo = 100600;
	static double balance = 0;
	
	static List<String> transactionDetails = new ArrayList<String>();
	String details;
	
	public void createCustomer() {
		
		customer.setCustomerId(++id);
		System.out.println("Enter the name:");
		String name = scanner.next();
		customer.setName(name);
		System.out.println("Enter the phone no:");
		long phoneNo = scanner.nextLong();
		customer.setPhoneNo(phoneNo);
		
		account.setAccountNo(++accountNo);
		account.setBalance(balance);
		
		customer.setAccount(account);
		
		service.createCustomerService(customer);
		
		System.out.println("Account Created.");
	}
	
	public void showBalance() {
		System.out.println("Enter the account No.");
		int accountNo = scanner.nextInt();
		Account account = service.showBalanceService(accountNo);
		System.out.println("Account No. : " + account.getAccountNo());
		System.out.println("Balance : " + account.getBalance());
	}
	
	public void deposit() {
		System.out.println("Enter the account no :");
		int depositAccount = scanner.nextInt();
		System.out.println("Enter the deposit amount : ");
		double depositAmount = scanner.nextDouble();
		service.depositService(depositAccount,depositAmount);
		System.out.println("Amount Deposited.");
		details = depositAmount + " deposited to account no " + depositAccount;
		transactionDetails.add(details);
	}
	
	public void withdraw() {
		System.out.println("Enter the account no :");
		int withdrawAccount = scanner.nextInt();
		System.out.println("Enter the withdraw amount : ");
		double withdrawAmount = scanner.nextDouble();
		service.withdrawService(withdrawAccount,withdrawAmount);
		System.out.println("Amount Withdraw Successful.");
		details = withdrawAmount + " withdraw from account no " + withdrawAccount;
		transactionDetails.add(details);
	}
	
	public void fundTransfer() {
		System.out.println("Enter the sender account no : ");
		int senderAccountNo = scanner.nextInt();
		System.out.println("Enter the receiver account no : ");
		int receiverAccountNo = scanner.nextInt();
		System.out.println("Enter the transfer amount : ");
		double transferAmount = scanner.nextDouble();
		service.fundTransferService(senderAccountNo, receiverAccountNo, transferAmount);
		System.out.println("Fund transfer successful.");
		details = transferAmount + " withdraw from account no " + senderAccountNo;
		transactionDetails.add(details);
		details = transferAmount + " deposited to account no " + receiverAccountNo;
		transactionDetails.add(details);
	}
	
	public void printTransaction() {
		for(String details : transactionDetails) {
			System.out.println(details);
		}
	}

}
